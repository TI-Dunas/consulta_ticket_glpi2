# Portal de Consulta de Chamados (GLPI)

Página pública, sem login, onde o usuário digita o **número do chamado** e vê o status,
as datas, o técnico e o histórico. A área **/admin** guarda a conexão com a API do GLPI
e define o que o portal mostra.

## 1. Subir o portal

Copie a pasta `portal-glpi` para o servidor (ex.: `/opt/portal-glpi`) e rode:

```bash
cd /opt/portal-glpi
nano docker-compose.yml        # troque PORTAL_SENHA
docker compose up -d --build
firewall-cmd --permanent --add-port=8090/tcp && firewall-cmd --reload
```

* Portal público: `http://IP_DO_SERVIDOR:8090`
* Administração: `http://IP_DO_SERVIDOR:8090/admin` (usuário `admin` e a senha do compose)

O portal responde em **HTTP** na porta 8090. Para trocar a porta, altere o primeiro número
da linha `"8090:8000"` no `docker-compose.yml` (o segundo, 8000, é interno e não muda) e
libere a nova porta no firewall. Para usar HTTPS, coloque um proxy reverso (Nginx, Apache)
com certificado na frente do portal.

O administrador do `docker-compose.yml` é criado só na primeira execução. Depois, troque a
senha pela própria área /admin. Se perder a senha, apague `data/users.json` e rode
`docker compose restart`.

## 2. Configurar a conexão (área /admin)

| Campo | Onde encontrar no GLPI |
|---|---|
| URL da API | `https://IP_DO_GLPI/apirest.php` |
| App Token | Configurar > Geral > API > (cliente da API) |
| User Token | Minhas configurações > Chaves de acesso remoto > Token da API |

Clique em **Testar conexão** e depois em **Salvar configurações**.

Use um **usuário do GLPI só para o portal**, que enxergue todas as entidades e leia
chamados e usuários. O cliente da API precisa estar ativo e liberar o IP do servidor
do portal.

## 3. O que o portal mostra

* Sempre: número, título, status (com explicação para o usuário), datas e categoria.
* Opcional: descrição, histórico, técnico, nomes das pessoas e prazo de SLA.
* **Nunca**: acompanhamentos/tarefas privados e anexos.

## 4. Segurança

Os números dos chamados são sequenciais. Com a consulta só pelo número, quem acessa o
portal pode tentar números em sequência e ler chamados de outras pessoas. Proteções:

* **Limite de consultas por minuto por IP** (padrão 10).
* **Exigir o e-mail do requerente** junto com o número (recomendado se o portal for
  acessado fora da rede interna). O e-mail é comparado com os e-mails do usuário
  requerente no GLPI e com o e-mail alternativo do chamado.
* Chamado inexistente e e-mail errado recebem a **mesma mensagem**, para não revelar
  quais números existem.
* Revise os textos dos chamados: o que estiver em acompanhamento **público** aparece no
  portal. Informações internas devem ser registradas como **privadas** no GLPI.

Se o portal ficar atrás de um proxy reverso, adicione no `docker-compose.yml` a variável
`FORWARDED_ALLOW_IPS=IP_DO_PROXY`. Assim o limite por IP passa a usar o IP real do
visitante (cabeçalho X-Forwarded-For), e não o IP do proxy.

## 5. Comandos úteis

```bash
docker compose logs -f          # acompanhar o funcionamento
docker compose restart          # reiniciar
docker compose up -d --build    # aplicar atualizações
```
