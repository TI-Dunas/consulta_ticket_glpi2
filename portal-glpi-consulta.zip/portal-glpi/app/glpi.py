"""Consulta de chamados na API REST do GLPI, reaproveitando a sessao entre consultas."""
import html
import re
import threading
import time
from datetime import datetime

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

STATUS = {
    1: ("Novo", "Recebido pela equipe de suporte, aguardando atendimento."),
    2: ("Em atendimento", "Um técnico está trabalhando no seu chamado."),
    3: ("Em atendimento (planejado)", "O atendimento está agendado."),
    4: ("Pendente", "Aguardando uma informação ou retorno para continuar."),
    5: ("Solucionado", "A solução foi registrada e aguarda a sua aprovação."),
    6: ("Fechado", "Chamado encerrado."),
}


class GlpiError(Exception):
    """Falha de comunicacao ou de configuracao (nao e 'chamado inexistente')."""


def parse_dt(valor):
    if not valor:
        return None
    try:
        return datetime.strptime(str(valor)[:19], "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def fmt(dt):
    return dt.strftime("%d/%m/%Y %H:%M") if dt else None


def normalizar_url(url):
    url = (url or "").strip().rstrip("/")
    if url and "apirest.php" not in url:
        url += "/apirest.php"
    return url


def texto_limpo(conteudo, limite=None):
    """HTML do GLPI -> texto puro (o portal nunca exibe HTML vindo do GLPI)."""
    t = str(conteudo or "")
    for _ in range(2):  # o GLPI costuma gravar o HTML ja codificado (&lt;p&gt;)
        t = html.unescape(t)
    t = re.sub(r"<(script|style)[^>]*>.*?</\1\s*>", "", t, flags=re.I | re.S)
    t = re.sub(r"<\s*(br|/p|/div|/li|/tr|/h\d)\s*/?>", "\n", t, flags=re.I)
    t = re.sub(r"<li[^>]*>", "• ", t, flags=re.I)
    t = re.sub(r"<[^>]+>", "", t)
    t = re.sub(r"[ \t\xa0]+", " ", t)
    t = re.sub(r"\n\s*\n\s*\n+", "\n\n", t).strip()
    if limite and len(t) > limite:
        t = t[:limite].rstrip() + "…"
    return t


class Conexao:
    """Mantem uma sessao da API aberta e refaz o login quando ela expira."""

    def __init__(self):
        self.trava = threading.Lock()
        self.token = None
        self.chave = None
        self.nomes = {}

    def _base(self, cfg):
        h = {"Content-Type": "application/json"}
        if cfg.get("app_token"):
            h["App-Token"] = cfg["app_token"]
        return h

    def _http(self, cfg, metodo, url, **kw):
        tentativas = max(1, int(cfg.get("retries") or 2))
        timeout = max(5, int(cfg.get("timeout") or 30))
        for n in range(1, tentativas + 1):
            try:
                return requests.request(metodo, url, verify=bool(cfg.get("verify_ssl")), timeout=timeout, **kw)
            except requests.exceptions.SSLError:
                raise GlpiError("Erro de certificado SSL ao acessar o GLPI. Desmarque 'Verificar certificado SSL'.")
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
                if n == tentativas:
                    raise GlpiError("O GLPI não respondeu. Tente novamente em alguns minutos.")
                time.sleep(2 * n)

    def _sessao(self, cfg, forcar=False):
        url = normalizar_url(cfg.get("glpi_url"))
        if not url or not cfg.get("user_token"):
            raise GlpiError("O portal ainda não foi configurado.")
        chave = (url, cfg.get("app_token"), cfg.get("user_token"), bool(cfg.get("verify_ssl")))
        with self.trava:
            if self.token and self.chave == chave and not forcar:
                return url, self.token
            h = self._base(cfg)
            h["Authorization"] = f"user_token {cfg['user_token']}"
            r = self._http(cfg, "GET", f"{url}/initSession", headers=h)
            if r.status_code != 200:
                self.token = None
                raise GlpiError(f"O GLPI recusou o login da API (HTTP {r.status_code}): {r.text[:200]}")
            self.token, self.chave = r.json()["session_token"], chave
            self.nomes = {}
            try:  # visao de todas as entidades do usuario da API
                self._http(cfg, "POST", f"{url}/changeActiveEntities",
                           headers={**self._base(cfg), "Session-Token": self.token},
                           json={"entities_id": 0, "is_recursive": True})
            except GlpiError:
                pass
            return url, self.token

    def get(self, cfg, caminho, params=None):
        url, token = self._sessao(cfg)
        r = self._http(cfg, "GET", f"{url}/{caminho}", headers={**self._base(cfg), "Session-Token": token}, params=params)
        if r.status_code == 401 and "SESSION" in r.text.upper():  # sessao expirou: novo login e repete
            url, token = self._sessao(cfg, forcar=True)
            r = self._http(cfg, "GET", f"{url}/{caminho}", headers={**self._base(cfg), "Session-Token": token}, params=params)
        if r.status_code >= 500:
            raise GlpiError("O GLPI apresentou um erro interno. Tente novamente em alguns minutos.")
        return r

    def lista(self, cfg, caminho):
        r = self.get(cfg, caminho)
        if r.status_code not in (200, 206):
            return []
        dados = r.json()
        return dados if isinstance(dados, list) else []

    def nome(self, cfg, uid):
        if not uid:
            return None
        if uid not in self.nomes:
            r = self.get(cfg, f"User/{uid}")
            if r.status_code == 200:
                u = r.json()
                self.nomes[uid] = " ".join(x for x in [u.get("firstname"), u.get("realname")] if x) or u.get("name")
            else:
                self.nomes[uid] = None
        return self.nomes[uid]

    def testar(self, cfg):
        self._sessao(cfg, forcar=True)
        r = self.get(cfg, "getFullSession")
        if r.status_code != 200:
            raise GlpiError(f"Login feito, mas a sessão não pôde ser lida (HTTP {r.status_code}).")
        perfil = (r.json().get("session") or {}).get("glpiactiveprofile", {}).get("name", "?")
        return f"Conexão OK. Usuário da API conectado com o perfil '{perfil}'."

    # ------------------------------------------------------------ consulta do chamado
    def consultar(self, cfg, numero, email=None):
        """Retorna os dados publicos do chamado, ou None se nao existir / nao puder ser exibido."""
        r = self.get(cfg, f"Ticket/{numero}", {"expand_dropdowns": "true"})
        if r.status_code != 200:
            return None
        t = r.json()
        if not isinstance(t, dict) or t.get("is_deleted"):
            return None

        atores = self.lista(cfg, f"Ticket/{numero}/Ticket_User")
        requerentes = {a.get("users_id") for a in atores if a.get("type") == 1 and a.get("users_id")}
        tecnicos = [a.get("users_id") for a in atores if a.get("type") == 2 and a.get("users_id")]

        if cfg.get("exigir_email"):
            informado = (email or "").strip().lower()
            if not informado:
                return None
            validos = {str(a.get("alternative_email") or "").strip().lower() for a in atores if a.get("type") == 1}
            for uid in requerentes:
                for e in self.lista(cfg, f"User/{uid}/UserEmail"):
                    validos.add(str(e.get("email") or "").strip().lower())
            if informado not in validos:
                return None

        mostrar_nomes = bool(cfg.get("mostrar_nomes"))
        status = int(t.get("status") or 0)
        nome_status, explicacao = STATUS.get(status, ("Desconhecido", ""))
        prazo = parse_dt(t.get("time_to_resolve"))
        solucao = parse_dt(t.get("solvedate"))
        agora = datetime.now()

        dados = {
            "numero": t.get("id"),
            "titulo": texto_limpo(t.get("name"), 200),
            "status": {"codigo": status, "nome": nome_status, "explicacao": explicacao},
            "abertura": fmt(parse_dt(t.get("date"))),
            "atualizacao": fmt(parse_dt(t.get("date_mod"))),
            "solucao": fmt(solucao),
            "fechamento": fmt(parse_dt(t.get("closedate"))),
            "categoria": texto_limpo(t.get("itilcategories_id")) if t.get("itilcategories_id") not in (0, "0", None) else None,
        }
        if cfg.get("mostrar_tecnico"):
            nomes = [self.nome(cfg, u) for u in tecnicos]
            dados["tecnicos"] = [n for n in nomes if n] or None
        if cfg.get("mostrar_sla") and prazo:
            if status in (5, 6):
                situacao = "Cumprido" if solucao and solucao <= prazo else "Fora do prazo"
            elif status == 4:
                situacao = "Pausado enquanto pendente"
            else:
                situacao = "Dentro do prazo" if agora <= prazo else "Prazo excedido"
            dados["sla"] = {"prazo": fmt(prazo), "situacao": situacao}
        if cfg.get("mostrar_descricao"):
            dados["descricao"] = texto_limpo(t.get("content"), 4000)

        if cfg.get("mostrar_historico"):
            eventos = [{"tipo": "abertura", "data": parse_dt(t.get("date")), "autor": None,
                        "texto": "Chamado aberto."}]
            for fu in self.lista(cfg, f"Ticket/{numero}/ITILFollowup"):
                if fu.get("is_private"):
                    continue  # nunca exibe acompanhamentos privados
                do_cliente = fu.get("users_id") in requerentes
                autor = (self.nome(cfg, fu.get("users_id")) if mostrar_nomes else None) or \
                        ("Solicitante" if do_cliente else "Equipe de suporte")
                eventos.append({"tipo": "cliente" if do_cliente else "suporte",
                                "data": parse_dt(fu.get("date_creation") or fu.get("date")),
                                "autor": autor, "texto": texto_limpo(fu.get("content"), 3000)})
            for s in self.lista(cfg, f"Ticket/{numero}/ITILSolution"):
                autor = (self.nome(cfg, s.get("users_id")) if mostrar_nomes else None) or "Equipe de suporte"
                eventos.append({"tipo": "solucao", "data": parse_dt(s.get("date_creation")), "autor": autor,
                                "texto": texto_limpo(s.get("content"), 3000)})
                if s.get("status") == 3 and parse_dt(s.get("date_approval")):
                    eventos.append({"tipo": "aprovada", "data": parse_dt(s.get("date_approval")), "autor": None,
                                    "texto": "Solução aprovada pelo solicitante."})
                elif s.get("status") == 4 and parse_dt(s.get("date_approval")):
                    eventos.append({"tipo": "recusada", "data": parse_dt(s.get("date_approval")), "autor": None,
                                    "texto": "Solução recusada pelo solicitante. O atendimento foi retomado."})
            if parse_dt(t.get("closedate")):
                eventos.append({"tipo": "fechamento", "data": parse_dt(t.get("closedate")), "autor": None,
                                "texto": "Chamado fechado."})
            eventos = [e for e in eventos if e["data"]]
            eventos.sort(key=lambda e: e["data"])
            for e in eventos:
                e["data"] = fmt(e["data"])
            dados["historico"] = eventos
        return dados
