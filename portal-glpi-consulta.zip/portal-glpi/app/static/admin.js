/* Area administrativa do portal */
(function () {
  "use strict";
  const $ = (s) => document.querySelector(s);

  async function api(url, corpo) {
    const op = corpo === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) };
    const r = await fetch(url, op);
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && !url.endsWith("/login")) { telaLogin(); throw new Error(j.detail || "Entre novamente."); }
    if (!r.ok) throw new Error(j.detail || `Erro HTTP ${r.status}`);
    return j;
  }

  function msg(id, tipo, texto) {
    const m = $(id);
    m.hidden = !texto;
    m.className = `mensagem ${tipo}`;
    m.textContent = texto || "";
  }

  function telaLogin() {
    $("#tela-login").hidden = false;
    $("#tela-config").hidden = true;
    $("#tela-senha").hidden = true;
    $("#l-usuario").focus();
  }

  const CAMPOS = [["#c-ssl", "verify_ssl"], ["#c-descricao", "mostrar_descricao"], ["#c-historico", "mostrar_historico"],
                  ["#c-tecnico", "mostrar_tecnico"], ["#c-nomes", "mostrar_nomes"], ["#c-sla", "mostrar_sla"],
                  ["#c-email", "exigir_email"]];

  function preencher(c) {
    $("#c-url").value = c.glpi_url || "";
    $("#c-app").value = ""; $("#c-user").value = "";
    $("#c-app").placeholder = c.app_token_set ? "•••••• (salvo; preencha só para trocar)" : "Configurar > Geral > API > Cliente da API";
    $("#c-user").placeholder = c.user_token_set ? "•••••• (salvo; preencha só para trocar)" : "Minhas configurações > Token da API";
    $("#c-app-limpar").checked = false;
    $("#c-timeout").value = c.timeout; $("#c-retries").value = c.retries;
    $("#c-titulo").value = c.titulo; $("#c-mensagem").value = c.mensagem;
    $("#c-limite").value = c.limite_por_minuto;
    CAMPOS.forEach(([id, k]) => { $(id).checked = !!c[k]; });
  }

  function lerForm() {
    const d = {
      glpi_url: $("#c-url").value.trim(), app_token: $("#c-app").value.trim(), user_token: $("#c-user").value.trim(),
      limpar_app_token: $("#c-app-limpar").checked, timeout: parseInt($("#c-timeout").value, 10) || 30,
      retries: parseInt($("#c-retries").value, 10) || 2, titulo: $("#c-titulo").value.trim(),
      mensagem: $("#c-mensagem").value.trim(), limite_por_minuto: parseInt($("#c-limite").value, 10) || 10,
    };
    CAMPOS.forEach(([id, k]) => { d[k] = $(id).checked; });
    return d;
  }

  async function telaConfig() {
    const c = await api("/api/admin/config");
    preencher(c);
    $("#tela-login").hidden = true;
    $("#tela-config").hidden = false;
    $("#tela-senha").hidden = false;
    if (!c.user_token_set) msg("#c-msg", "info", "Primeiro acesso: informe a URL da API e os tokens do GLPI, teste a conexão e salve.");
  }

  $("#form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await api("/api/admin/login", { username: $("#l-usuario").value.trim(), password: $("#l-senha").value });
      $("#l-senha").value = "";
      msg("#l-msg", "erro", "");
      telaConfig();
    } catch (err) { msg("#l-msg", "erro", err.message); }
  });

  $("#btn-testar").addEventListener("click", async () => {
    msg("#c-teste", "info", "Testando a conexão…");
    try { const r = await api("/api/admin/teste", lerForm()); msg("#c-teste", r.ok ? "ok" : "erro", r.message); }
    catch (err) { msg("#c-teste", "erro", err.message); }
  });

  $("#form-config").addEventListener("submit", async (e) => {
    e.preventDefault();
    try { preencher(await api("/api/admin/config", lerForm())); msg("#c-msg", "ok", "Configurações salvas."); }
    catch (err) { msg("#c-msg", "erro", err.message); }
  });

  $("#form-senha").addEventListener("submit", async (e) => {
    e.preventDefault();
    if ($("#s-nova").value !== $("#s-repete").value) { msg("#s-msg", "erro", "A nova senha e a repetição não são iguais."); return; }
    try {
      await api("/api/admin/senha", { atual: $("#s-atual").value, nova: $("#s-nova").value });
      ["#s-atual", "#s-nova", "#s-repete"].forEach((s) => { $(s).value = ""; });
      msg("#s-msg", "ok", "Senha alterada.");
    } catch (err) { msg("#s-msg", "erro", err.message); }
  });

  $("#btn-sair").addEventListener("click", async () => { await fetch("/api/admin/logout", { method: "POST" }); telaLogin(); });

  fetch("/api/admin/me").then((r) => (r.ok ? telaConfig() : telaLogin())).catch(telaLogin);
})();
